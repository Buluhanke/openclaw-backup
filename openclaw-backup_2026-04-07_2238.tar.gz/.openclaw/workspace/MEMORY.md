# MEMORY.md - 长期记忆

## 关于元哥
- **Name:** 元哥
- **What to call them:** 元哥（老大）
- **Pronouns:** 未知
- **Timezone:** Asia/Shanghai (GMT+8)
- **喜欢用中文交流**

## 渠道说明
- 微信（openclaw-weixin）和企业微信（openclaw-wecom）都是同一个人，都是元哥本人
- **分开使用**：企业微信和微信是两个独立对话渠道，各有各的上下文

## 主要需求
- 1688 批发找货
- 想看月销量和价格档位匹配最低价货源

## 定时提醒
- **4月18日**：MiniMax-M2.7 到期 → 切换 Ollama 本地模型 `ollama/qwen2.5:7b`
  - 切换命令：`openclaw config set agents.defaults.model.primary ollama/qwen2.5:7b && openclaw gateway restart`

## 铁律
- **不掉线规则**：主 LLM 或网关掉线 → 立即切换 Ollama 本地大模型 → 网关每分钟重启一次直到恢复

## 关于我（小助）
- **Name:** 小助
- **Creature:** AI助手
- **Vibe:** 温暖、实用、有个性、聪明
- **Emoji:** ✨

## 本次 session 记录（2026-04-02）
### 环境配置
- 解决了 openclaw-tui 连接 gateway 时的 token 认证问题：用 `openclaw devices list` 看到待批准请求，用 `openclaw devices approve <id>` 批准后 tui 才能正常连接
- 终端中文设置：`export LANG=zh_CN.UTF-8` 已写入 ~/.zshrc
- 修复了 ~/.zshrc 第15行错误（source openclaw.zsh 文件不存在）

### GitHub 仓库
- 克隆了 https://github.com/Buluhanke/OpenClaw.git 到 ~/OpenClaw
- 仓库里有 AGENTS.md、SOUL.md、IDENTITY.md、MEMORY.md、USER.md 等配置文件
- MEMORY.md 里有关于元哥和小助的身份信息已同步到工作区

### 技能状态
- 内置技能：clawhub、clawflow、clawflow-inbox-triage、healthcheck、node-connect、skill-creator、weather、qqbot-channel、qqbot-media、qqbot-remind
- clawhub 搜索到的第三方技能：coding-agent、discord、eightctl、gemini、gh-issues、gifgrep、github、gog、goplaces、himalaya、imsg、mcporter、model-usage、nano-pdf、notion、obsidian、openai-whisper、openai-whisper-api、openhue、oracle、ordercli、peekaboo、sag、session-logs、sherpa-onnx-tts、slack、songsee、sonoscli、spotify-player、summarize、things-mac、tmux、trello、video-frames、voice-call、wacli、weather、xurl
- **未找到 1688 相关技能**，元哥想要一个 1688 货源搜索的技能（查月销量、价格档位、匹配最低价）
