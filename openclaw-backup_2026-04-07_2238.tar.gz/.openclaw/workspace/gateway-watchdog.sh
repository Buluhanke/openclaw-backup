#!/bin/bash
# Gateway Watchdog - 每15分钟检查一次，崩溃则重启
export PATH="/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin"
LOG="$HOME/.openclaw/workspace/logs/gateway-watchdog.log"
mkdir -p "$(dirname "$LOG")"

STATUS=$(/usr/local/bin/openclaw gateway status 2>/dev/null | grep "Runtime.*running" | head -1)
if echo "$STATUS" | grep -q "running"; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') OK" >> "$LOG"
else
  echo "$(date '+%Y-%m-%d %H:%M:%S') CRASHED - restarting..." >> "$LOG"
  /usr/local/bin/openclaw gateway restart >> "$LOG" 2>&1
fi
