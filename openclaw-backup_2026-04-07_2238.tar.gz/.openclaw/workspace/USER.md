# USER.md - About Your Human

- **Name:** 元哥
- **What to call them:** 元哥（老大）
- **Pronouns:** 未知
- **Timezone:** Asia/Shanghai (GMT+8)
- **Notes:** 喜欢用中文交流

## 渠道说明
- 微信（openclaw-weixin）和企业微信（openclaw-wecom）都是同一个人，都是元哥本人
- **分开使用**：企业微信和微信是两个独立对话渠道，各有各的上下文

## 主要需求
- 1688 批发找货
- 想看月销量和价格档位匹配最低价货源
