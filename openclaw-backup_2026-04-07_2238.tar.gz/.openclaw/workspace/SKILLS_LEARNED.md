# 🎓 OpenClaw 全部技能学习笔记

> 本文件由小助于 2026-04-05 系统学习整理，包含 118 个技能的用途、核心功能、使用方法和注意事项。

---

## 📂 技能分类总览

| 类别 | 数量 | 说明 |
|------|------|------|
| 企业微信插件 | 15 | @wecom 开头的技能 |
| 工作区技能 | 35+ | ~/.openclaw/workspace/skills |
| 内置技能 | 60+ | OpenClaw 自带技能 |
| QQ机器人 | 3 | qqbot 相关技能 |

---

## 🔷 企业微信插件（@wecom）

### 💬 wecom-msg（消息）
- **用途**：会话列表查询、消息记录拉取、文件下载、发送消息
- **核心功能**：
  - `get_msg_chat_list` — 获取会话列表
  - `get_message` — 拉取消息（仅7天内）
  - `get_msg_media` — 下载图片/文件/语音/视频
  - `send_message` — 发送文本消息
- **注意**：时间格式 `YYYY-MM-DD HH:mm:ss`，默认查7天

### 📇 wecom-contact-lookup（通讯录）
- **用途**：查询企业通讯录成员
- **核心功能**：`get_userlist` 获取可见范围成员
- **注意**：返回 userid、name、alias；超过10人报错

### 📄 wecom-doc-manager（文档管理）
- **用途**：企业微信文档、智能表格、智能主页的 CRUD
- **URL 路由**：
  - `/doc/*` → 文档（doc_type=3）
  - `/smartsheet/*` → 智能表格（doc_type=10）
  - `/smartpage/*` → 智能主页
- **核心接口**：
  - `get_doc_content` — 异步轮询获取内容
  - `create_doc` — 新建文档/智能表格
  - `edit_doc_content` — Markdown 覆写
  - `smartpage_create` — 创建智能主页
  - `smartpage_export_task` — 异步导出智能主页

### 📊 wecom-smartsheet-data（智能表格数据）
- **用途**：管理智能表格记录（行数据）
- **核心接口**：
  - `smartsheet_get_records` — 查询记录
  - `smartsheet_add_records` — 添加记录
  - `smartsheet_update_records` — 更新记录
  - `smartsheet_delete_records` — 删除记录
- **注意**：成员字段需填 userid，先用 `wecom-contact-lookup` 查询

### 🗓️ wecom-schedule（日程管理）
- **用途**：日程的查询、创建、修改、取消
- **核心接口**：
  - `get_schedule_list_by_range` — 查询日程（仅前后30天）
  - `get_schedule_detail` — 获取详情
  - `create_schedule` — 创建日程
  - `update_schedule` — 修改日程
  - `cancel_schedule` — 取消日程
  - `check_availability` — 查询闲忙状态

### 🤖 wecom-edit-todo（待办编辑）
- **用途**：创建、更新、删除待办事项

### 📋 wecom-get-todo-list（待办列表）
- **用途**：查询待办列表，支持分页和过滤

### 🔍 wecom-get-todo-detail（待办详情）
- **用途**：批量获取待办完整信息

### 📅 wecom-meeting-create（创建会议）
- **用途**：预约会议

### ⚙️ wecom-meeting-manage（管理会议）
- **用途**：取消会议、更新会议成员

### 🔎 wecom-meeting-query（查询会议）
- **用途**：会议列表、详情、关键词查找

### 🖼️ wecom-send-media（发送文件）
- **用途**：发送图片、视频、语音、文件

### 📨 wecom-send-template-card（卡片消息）
- **用途**：发送结构化卡片消息（通知、投票、按钮选择等）

### ⚡ wecom-preflight（前置检查）
- **用途**：首次调用 wecom_mcp 前检查工具权限配置

---

## 🔧 内置技能（OpenClaw）

### 🪝 clawflow（任务流编排）
- **用途**：多步骤后台任务管理，跨 prompt 保持上下文
- **核心概念**：flow identity、owner session、waiting state、persisted outputs
- **使用场景**：需要多步骤、有条件分支、等待子任务结果的复杂工作流
- **示例**：
  ```
  createFlow() → runTaskInFlow() → setFlowWaiting() → resumeFlow() → finishFlow()
  ```

### 📦 clawhub（技能市场）
- **用途**：搜索、安装、更新、发布技能
- **常用命令**：
  - `clawhub search "关键词"`
  - `clawhub install <skill-name>`
  - `clawhub update <skill-name>`
  - `clawhub publish ./skill-folder`

### 🛡️ healthcheck（安全检查）
- **用途**：主机安全审计、防火墙/SSH/更新加固
- **工作流**：读取检查 → 风险评估 → 修复计划 → 用户确认 → 执行
- **重要**：需要用户明确授权才能执行修改操作

### 🛠️ skill-creator（技能创建）
- **用途**：创建、编辑、改进、审计 AgentSkills
- **技能结构**：
  - SKILL.md（必需）：name、description、body
  - scripts/：可执行脚本
  - references/：参考文档
  - assets/：静态资源
- **原则**：简洁优先；根据任务脆弱程度设置自由度

### ☔ weather（天气）
- **用途**：获取天气预报
- **命令**：`curl "wttr.in/城市?format=3"`
- **注意**：无需 API key，使用 wttr.in

### 🐙 github（GitHub CLI）
- **用途**：通过 `gh` CLI 操作 GitHub
- **核心功能**：PR 列表/状态/创建/合并、Issue 管理、CI 运行日志、API 查询
- **注意**：本地 git 操作用 `git` 命令，不需要 gh

### 🐛 gh-issues（GitHub Issues 自动修复）
- **用途**：自动抓取 Issue、派生子代理修复、打开 PR、监控 PR 评论
- **6 个阶段**：解析参数 → 抓取 Issue → 确认 → 预检 → 并行子代理 → PR 审查
- **重要**：使用 curl + GitHub REST API，不依赖 gh CLI

### 🧩 coding-agent（代码代理）
- **用途**：委托编码任务给 Codex、Claude Code 等
- **核心参数**：
  - Codex/Pi/OpenCode：需要 `pty:true`
  - Claude Code：`--print --permission-mode bypassPermissions`
- **注意**：
  - 永远不要在 `~/.openclaw` 目录运行编码代理
  - PR 审查要在临时目录执行

### 🔌 node-connect（节点连接诊断）
- **用途**：诊断 OpenClaw 节点配对失败问题
- **常见场景**：QR 码失败、Tailscale 问题、pairing required

### 🔍 neuraldebug（AI调试）
- **用途**：AI驱动的程序调试 + LLM可解释性分析
- **支持语言**：Python, C/C++, C#, Rust, Java, Go, Node.js, Ruby
- **LLM调试**：Logit Lens、Attention Analysis、Probing、Activation Patching
- **Fine-tuning**：支持 LoRA 微调 GPT-2 系列

### 🎵 spotify-player（Spotify控制）
- **工具**：spogo（推荐）或 spotify_player
- **要求**：Spotify Premium 账号

### 📝 notion（Notion API）
- **用途**：Notion 页面/数据库/块的 CRUD
- **注意**：
  - API Version: 2025-09-03
  - 数据库叫 "data source"
  - 需要先分享页面给集成

### ⏰ apple-reminders（Apple提醒）
- **工具**：remindctl
- **注意**：
  - macOS 专用
  - 与 OpenClaw 定时任务不同（那是内部任务）

### 💡 openhue（Philips Hue控制）
- **用途**：控制 Hue 灯和场景
- **注意**：仅支持 Hue 设备

### 🧾 summarize（内容摘要）
- **用途**：URL/文件/YouTube 内容摘要
- **命令**：`summarize "URL" --model google/gemini-3-flask-preview`

### 📨 imsg（iMessage）
- **用途**：macOS iMessage 读写
- **注意**：仅 macOS，需要完整磁盘访问权限

### 🗂️ session-logs（会话日志）
- **用途**：查看和管理 OpenClaw 会话历史

### 📊 model-usage（模型使用统计）
- **用途**：查看模型使用情况和成本

### 🌐 discord（Discord管理）
- **用途**：消息、反应、线程、投票、表情上传
- **注意**：Discord 风格要会话式、短句、避免 Markdown 表格

### 📚 qqbot-channel（QQ频道管理）
- **用途**：查询频道、子频道、成员、发帖、公告

### 📎 qqbot-media（QQ富媒体）
- **用途**：发送图片、语音、视频、文件

### ⏱️ qqbot-remind（QQ定时提醒）
- **用途**：创建和管理 QQ 内定时提醒

### 🎮 slack（Telegram/Slack等）
- **用途**：各平台消息管理

### 📋 trello（Trello）
- **用途**：Trello 看板任务管理

### 🗓️ things-mac（Things.app）
- **用途**：macOS Things 任务管理

### 📔 bear-notes（Bear笔记）
- **用途**：Bear 笔记应用操作

### 📱 apple-notes（Apple笔记）
- **用途**：Apple Notes 应用操作

### 🎨 canvas（白板）
- **用途**：设计白板操作

### 📺 video-frames（视频帧提取）
- **用途**：从视频提取帧

### 🔊 openai-whisper（语音转文字）
- **用途**：音频转写

### 🎤 voice-call（语音通话）
- **用途**：语音通话管理

### 🌄 gog（旅行规划）
- **用途**：旅行规划

### 🛒 ordercli（订单管理）
- **用途**：订单处理

### 🧮 oracle（甲骨文/占卜）
- **用途**：随机响应/占卜

### 🐕 peekaboo（相机管理）
- **用途**：相机控制

### 📹 camsnap（相机拍照）
- **用途**：拍照功能

### 🔊 sherpa-onnx-tts（离线TTS）
- **用途**：离线文字转语音

### 🌐 xurl（URL操作）
- **用途**：URL 处理

### 📦 nano-pdf（PDF处理）
- **用途**：PDF 读取

### 🗃️ obsidian（Obsidian笔记）
- **用途**：Obsidian Vault 操作

### 📈 blogwatcher（博客监控）
- **用途**：博客更新监控

### 🧪 gog（Go语言？）
- **用途**：待确认

### 🖥️ tmux（终端复用）
- **用途**：tmux 会话管理

### 🔑 1password（密码管理）
- **用途**：1Password 集成

### 📶 blucli（蓝牙控制）
- **用途**：蓝牙设备控制

### 🔵 bluebubbles（iMessage桥接）
- **用途**：iMessage BlueBubbles 桥接

### 📐 eightctl（八段数码管？）
- **用途**：待确认

### 🚗 himalaya（邮件客户端）
- **用途**：邮件管理

### ✈️ gemini（Gemini集成）
- **用途**：Google Gemini AI 集成

### 🧊 gifgrep（GIF搜索）
- **用途**：GIF 动图搜索

### 🏠 goplaces（地点管理）
- **用途**：地点/位置服务

### 📡 wacli（WA CLI）
- **用途**：WhatsApp CLI

---

## 🔶 工作区技能（~/.openclaw/workspace/skills）

### 🛒 1688-distributor（1688分销铺货）
- **用途**：1688 AI 选品、自动铺货到店铺
- **流程**：AI 选品 → 全选商品 → 立即铺货 → 查看日志
- **注意**：需要提供店铺名称和选品条件

### 🛒 query-1688-product-detail（1688商品详情）
- **用途**：查询 1688 商品详情（月销量、价格档位等）
- **注意**：使用 AlphaShop API，不使用浏览器爬虫

### 📚 ai-deep-learning（深度学习）
- **用途**：系统化深度学习方法论，引文网络提纯 + 多AI交叉质询

### 👔 ai-era-leadership（AI时代领导力）
- **用途**：AI 时代的领导力培养，不可替代的人类能力

### 🔥 baidu-hot-cn（百度热榜）
- **用途**：获取百度热搜榜

### 💰 fanvue（Fanvue平台）
- **用途**：Fanvue 内容/聊天/订阅者/收入管理
- **认证**：OAuth 2.0 + PKCE

### 🎨 frontend-design-pro（前端设计审计）
- **用途**：UI 设计质量提升，audit/polish/critique

### 📚 learn-cog（AI导师）
- **用途**：CellCog 驱动的 AI 辅导，多种解释方式

### 🎬 luma-ai（Luma视频生成）
- **用途**：Luma Dream Machine 文生视频、图生视频
- **提示词结构**：[主体] + [动作] + [场景] + [镜头] + [风格]

### 🔮 memory-never-forget（记忆系统v3.1）
- **用途**：Atkinson-Shiffrin 时间分层 + 4类型分类

### 💾 memory-on-demand（按需记忆）
- **用途**：语义搜索记忆文件

### ⚙️ memory-setup（记忆配置）
- **用途**：配置 OpenClaw 记忆系统

### 🧠 elite-longterm-memory-local（本地向量记忆）
- **用途**：LanceDB + 纯 JS embedding，无需外部 API

### 🧠 neural-memory（神经记忆）
- **用途**：神经记忆系统

### 🧠 memory-networks（记忆网络）
- **用途**：记忆网络系统

### 🧠 fluid-memory（流式记忆）
- **用途**：流式记忆系统

### 🧠 ntm-memory-system（神经图灵机记忆）
- **用途**：NTM 记忆系统

### 🧠 openclaw-memory（OpenClaw记忆）
- **用途**：OpenClaw 记忆集成

### 📝 self-learning（自我学习）
- **用途**：分析对话历史，自动更新 MEMORY.md、USER.md 等配置文件

### 📝 self-improving-agent-cn（自我改进）
- **用途**：AI 自我改进，捕获错误和纠正

### 📝 self-improving（自我改进）
- **用途**：自我反思 + 自我批评

### 📝 self-improving-1-2-10（自我改进）
- **用途**：自我改进版本

### 📝 self-improving-agent-1-0-2（自我改进）
- **用途**：自我改进版本

### 🐹 hamster-self-improving（仓鼠自我改进）
- **用途**：自改进系统

### 🔄 clawmage-learning-loop（学习循环）
- **用途**：主动学习引擎，日记 + 决策跟踪 + 课程提取

### 🧪 ml-training（机器学习训练）
- **用途**：ML 模型训练

### 🖥️ ui-ux-dev（UI开发）
- **用途**：React 页面生成和服务

### 🎨 ui-ux-design（UI设计）
- **用途**：UI 设计资源库

### 🎨 ui-ux-pro-max（UI/UX高级）
- **用途**：专业 UI/UX 资源库

### 🎨 ui-ux-pro-max-plus（UI/UX高级+）
- **用途**：专业 UI/UX 资源库增强版

### 🎨 ui-skills（UI约束）
- **用途**：构建更好界面的约束规范

### 🔍 ui-audit（UI审计）
- **用途**：自动化 UI 审计

### 🖼️ rmn-visualizer（RMN可视化）
- **用途**：可视化工具

### 🔧 linux-service-triage（Linux服务诊断）
- **用途**：诊断常见 Linux 服务问题

### 🤖 test-master（测试大师）
- **用途**：全面的测试策略和自动化
- **核心**：功能测试 + 性能测试 + 安全测试

### 🧬 ctf-ai-ml（CTF AI/ML挑战）
- **用途**：CTF 机器学习挑战

### 📺 trmnl（TRMNL电子纸）
- **用途**：TRMNL e-ink 显示设备内容生成
- **结构**：layout + title_bar 模式

### 🪟 discord（Discord）
- **用途**：Discord 管理（与内置 discord 重复）

---

## 📌 重要技能组合

### 1688 批发找货工作流
1. **query-1688-product-detail** — 查询商品详情（月销量、价格）
2. **1688-distributor** — AI 选品铺货

### 企业微信办公
1. **wecom-msg** — 查看消息
2. **wecom-contact-lookup** — 查人
3. **wecom-schedule** — 查日程
4. **wecom-doc-manager** — 文档管理
5. **wecom-smartsheet-data** — 表格数据

### GitHub 自动化
1. **github** — 基础操作
2. **gh-issues** — 自动修复 Issue

### 代码开发
1. **coding-agent** — 委托编码
2. **neuraldebug** — 调试
3. **test-master** — 测试

### 自我提升
1. **self-learning** — 自我学习
2. **memory-never-forget** — 记忆系统
3. **learn-cog** — 学习辅导

---

## ⚠️ 注意事项

1. **企业微信技能**：首次调用前必须执行 `wecom-preflight` 检查
2. **coding-agent**：永远不要在 `~/.openclaw` 目录运行
3. **GitHub**：本地 git 操作用 `git`，API 操作用 `github` 或 `gh-issues`
4. **Discord**：保持会话式风格，短句，避免 Markdown 表格
5. **天气**：无需 API key，使用 wttr.in
6. **1688**：使用 API 而非爬虫

---

## 📝 待探索技能

以下技能需要进一步了解：
- oracle（甲骨文）
- eightctl
- gog
- nano-pdf
- peekaboo
- camsnap
- sherpa-onnx-tts
- wacli
- 1password
- blucli
- bluebubbles
- gifgrep
- goplaces
- blogwatcher
- tmux
- obsidian
- himalaya
- xurl
- voice-call

---

*最后更新：2026-04-05 by 小助 ✨*
